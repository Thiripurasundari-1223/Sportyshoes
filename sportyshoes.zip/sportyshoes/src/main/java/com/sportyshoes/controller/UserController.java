package com.sportyshoes.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.sportyshoes.exception.MyResourceNotCreatedException;
import com.sportyshoes.model.Order;
import com.sportyshoes.model.Product;
import com.sportyshoes.model.User;
import com.sportyshoes.service.UserService;

@RestController
@RequestMapping("/api/")
public class UserController {

	@Autowired
	UserService userService;

	@PostMapping("/user/signup")
	private String userSignup(@RequestBody User user) {
		try {
			userService.createUser(user);
			return "User Created!!";
		} catch (MyResourceNotCreatedException e) {
			return e.getMessage();
		}
	}

	
	@GetMapping("/user/signin")
	private String userSigin(@RequestBody User userData){
		System.out.println(userData);
		List<User> users=userService.getAllUsers();
		for(User user:users) {
			
			if (user.getUserName().equals(userData.getUserName()) && user.getPassword().equals(userData.getPassword())) {
				return	"User signin successfully!!";
			}
		}
		return "Invalid User";
		
	}
	
	@PostMapping("user/{userId}/product/{prodId}/order")
	private Order purchaseOrder(@PathVariable Integer userId,@PathVariable Integer prodId,@RequestBody Order order) {
		
		return userService.purchaseOrder(userId,prodId,order);
		
	}
	
	
	@GetMapping("/products/all")
	private List<Product> getProductList(){
		List<Product> list=userService.getProductsList();
		return list;
		
	}
	
	
	@GetMapping("/product/search")
	private List<Product> getProductsByName(@RequestParam String prodName){
		List<Product> products=userService.getProductsByName(prodName); 
		return products;
	}
	
	@GetMapping("/product/{prodId}")
	private  Optional<Product> getProductById(@PathVariable Integer prodId){
		 Optional<Product> product=userService.getProductById(prodId); 
		return product;
	}
	
	@GetMapping("/user/{userId}")
	private Optional<User> getUser(@PathVariable Integer userId) {
		Optional<User> user=userService.getUser(userId);
		return user;
	}
	
	
	
	@PatchMapping("/user/{userId}/update/username")
	private String changeUserName(@PathVariable Integer userId, @RequestBody String userName) {
		userService.changeUserName(userId,userName);
		return "Username updated successfully";
		
	}
	
	@PatchMapping("/user/{userId}/update/password")
	private String changeUserPassword(@PathVariable Integer userId, @RequestBody String password) {
		userService.changeUserPassword(userId,password);
		return "Password updated successfully";
		
	}
	
	
	@GetMapping("/user/{userId}/order/all")
	private List<Order> getUserOrders(@PathVariable Integer userId){
		
		return userService.getUserOrders(userId);
	}
	
}
