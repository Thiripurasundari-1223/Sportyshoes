package com.sportyshoes.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.sportyshoes.exception.MyResourceNotCreatedException;
import com.sportyshoes.model.Order;
import com.sportyshoes.model.Product;
import com.sportyshoes.model.User;
import com.sportyshoes.service.AdminService;
import com.sportyshoes.service.UserService;

@RestController
@RequestMapping("/api/")
public class AdminController {

	@Autowired
	AdminService adminService;
	
	@Autowired 
	UserService userService;
	
	@PatchMapping ("/admin/{adminId}/update/password")
	private String changeAdminPassword(@PathVariable String adminId,@RequestBody String password) {
		adminService.changeAdminPassword(adminId,password);
		return "Password Updated Successfully";
		
	}
	
	
	@GetMapping("user/all")
	private List<User> getAllUsers(){
		return adminService.getAllUsers();
	}
	
	@GetMapping("user/search")
	private User getUsersByName(@RequestParam String userName){
		return adminService.getUsersByName(userName);
	}
	
	
	
	@PostMapping("product/add")
	private String createProduct(@RequestBody Product product) {
				try {
					adminService.createProduct(product);
					return "new Product added!!";
				} catch (MyResourceNotCreatedException e) {
					return e.getMessage();
				}
	}
	
	@GetMapping("/order/all/sorted")
	private List<Order> getOrdersBySortingField(@RequestParam String key ,@RequestParam String ordering){
		return adminService.getOrdersBySortingField(key,ordering);
	}
	
	@DeleteMapping("product/{prodId}/delete")
	private String deleteProduct(@PathVariable Integer prodId) {
		boolean productBool =adminService.deleteProduct(prodId);
		if(productBool) {
		return "Product deleted!!";
		}
		return "Couldn't delete the product";
	}
	
	@PatchMapping ("/product/{prodId}/update/msrp")
	private String changeProductMsrp(@PathVariable Integer prodId,@RequestBody Double msrp) {
		adminService.changeProductMsrp(prodId,msrp);
		return "Product MSRP Updated!!";
		
	}
}
