package com.sportyshoes.exception;

public class MyResourceNotCreatedException  extends RuntimeException{

	private static final long serialVersionUID = 1L;

	public MyResourceNotCreatedException(String errorMessage) {
		super(errorMessage);
	}
}
