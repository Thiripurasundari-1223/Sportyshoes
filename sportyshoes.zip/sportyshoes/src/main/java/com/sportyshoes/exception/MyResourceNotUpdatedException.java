package com.sportyshoes.exception;

public class MyResourceNotUpdatedException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MyResourceNotUpdatedException(String errormessage) {
		super(errormessage);
	}
}
