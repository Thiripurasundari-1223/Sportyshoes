package com.sportyshoes.exception;

public class MyResourceNotFoundException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public MyResourceNotFoundException(String errormessage) {
		super(errormessage);
	}
}
