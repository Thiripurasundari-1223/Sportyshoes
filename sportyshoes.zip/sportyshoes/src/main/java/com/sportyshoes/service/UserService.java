package com.sportyshoes.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ExceptionHandler;
import com.sportyshoes.exception.MyResourceNotCreatedException;
import com.sportyshoes.exception.MyResourceNotDeletedException;
import com.sportyshoes.exception.MyResourceNotFoundException;
import com.sportyshoes.exception.MyResourceNotUpdatedException;
import com.sportyshoes.model.Order;
import com.sportyshoes.model.Product;
import com.sportyshoes.model.User;
import com.sportyshoes.repository.ProductRepository;
import com.sportyshoes.repository.UserRepository;
import com.sportyshoes.repository.OrderRepository;

@Service
public class UserService {

	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;

	@Autowired
	OrderRepository orderRepository;

	@ExceptionHandler({ MyResourceNotCreatedException.class, MyResourceNotFoundException.class,
			MyResourceNotUpdatedException.class, MyResourceNotDeletedException.class })

	public void createUser(User user) {

		User record = userRepository.save(user);
		if (record == null)
			throw new MyResourceNotCreatedException("Couldn't create new user");

	}

	public List<Product> getProductsList() {
		List<Product> prods = productRepository.findAll();
		if (prods == null)
			throw new MyResourceNotFoundException("Products not available!!");

		return prods;

	}

	public List<Product> getProductsByName(String prodName) {
		List<Product> products = productRepository.findByProdName(prodName);
		System.out.println("service" + products);
		return products;
	}

	public Optional<User> getUser(Integer userId) {

		return userRepository.findById(userId);
	}

	public void changeUserPassword(Integer userId, String password) {

		User user = userRepository.getById(userId);
		if (user != null) {
			user.setPassword(password);
		}
		userRepository.save(user);

	}

	public Optional<Product> getProductById(Integer prodId) {
		return productRepository.findById(prodId);
	}

	public void changeUserName(Integer userId, String userName) {
		User user = userRepository.getById(userId);
		if (user != null) {
			user.setPassword(userName);
		}
		userRepository.save(user);

	}

	public List<Order> getUserOrders(Integer userId) {
		List<Order> orders = orderRepository.findByUserId(userId);
		return orders;

	}

	public Order purchaseOrder(Integer userId, Integer prodId, Order order) {
		System.out.println(order);
		order.setUserId(userId);
		order.setProdId(prodId);

		return orderRepository.save(order);
	}

	public List<User> getAllUsers() {
		
		return userRepository.findAll();
	}

}
