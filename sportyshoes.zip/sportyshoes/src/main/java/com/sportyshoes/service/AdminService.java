package com.sportyshoes.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;
import com.sportyshoes.exception.MyResourceNotCreatedException;
import com.sportyshoes.exception.MyResourceNotDeletedException;
import com.sportyshoes.exception.MyResourceNotUpdatedException;
import com.sportyshoes.model.Admin;
import com.sportyshoes.model.Order;
import com.sportyshoes.model.Product;
import com.sportyshoes.model.User;
import com.sportyshoes.repository.AdminRepository;
import com.sportyshoes.repository.OrderRepository;
import com.sportyshoes.repository.ProductRepository;
import com.sportyshoes.repository.UserRepository;

@Service
public class AdminService {

	@Autowired
	AdminRepository adminRepository;
	@Autowired
	UserRepository userRepository;
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	OrderRepository orderRepository;
	
	public void changeAdminPassword(String adminId, String password) {
	
		Admin admin=adminRepository.getById(adminId);
		if(admin!=null) {
			admin.setPassword(password);	
		}
		adminRepository.save(admin);
	}

	public List<User> getAllUsers() {
		List<User> users=userRepository.findAll();
		return users;	
	}

	public User getUsersByName(String userName) {
		User users=userRepository.findByUserName(userName);
		return users;	
	}

	public void createProduct(Product product) {
		Product prodRecord = productRepository.save(product);
		if (prodRecord == null)
			throw new MyResourceNotCreatedException("Couldn't add new product!!");
	
	}

	public List<Order> getOrdersBySortingField(String key, String ordering) {
		List<Order> orders = null;
		if (ordering.equals("Desc")) {
			orders = orderRepository.findAll(Sort.by(Direction.DESC, key));
			return orders;
		} else {
			orders = orderRepository.findAll(Sort.by(Direction.ASC, key));
			return orders;
		}

	}

	public boolean deleteProduct(Integer prodId) {
		try {
			productRepository.deleteById(prodId);
			return true;
		} catch (MyResourceNotDeletedException e) {
			e.getMessage();
		}
		return false;

	}

	public String changeProductMsrp(Integer prodId, Double msrp) {
	
		Product prod=productRepository.getById(prodId);
		if(prod!=null) {
			prod.setProdMsrp(msrp);
			productRepository.save(prod);
			return "Product MSRP Updated!!";
		}
		throw new MyResourceNotUpdatedException("Product MSRP not updated!!");
		
	
		
	}
}
