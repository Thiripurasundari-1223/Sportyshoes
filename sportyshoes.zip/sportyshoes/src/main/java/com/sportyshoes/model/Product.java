package com.sportyshoes.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="product")
public class Product {

	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="PROD_ID")
	private Integer prodId;
	
	@Column(name="PROD_NAME")
	private String prodName;
	
	@Column(name="MSRP")
	private Double prodMsrp;
	
	@Column(name="STOCK_QUANTITY")
	private Integer prodQuantityInStock;
	
	@Column(name="VENDOR")
	private String vendor;
	
	
	public Product() {
		super();
	}
	public Product( String prodName, Double prodMsrp, Integer prodQuantityInStock, String vendor) {
		super();
		this.prodName = prodName;
		this.prodMsrp = prodMsrp;
		this.prodQuantityInStock = prodQuantityInStock;
		this.vendor = vendor;
	}
	
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public Double getProdMsrp() {
		return prodMsrp;
	}
	public void setProdMsrp(Double prodMsrp) {
		this.prodMsrp = prodMsrp;
	}
	public Integer getProdQuantityInStock() {
		return prodQuantityInStock;
	}
	public void setProdQuantityInStock(Integer prodQuantityInStock) {
		this.prodQuantityInStock = prodQuantityInStock;
	}
	public String getVendor() {
		return vendor;
	}
	public void setVendor(String vendor) {
		this.vendor = vendor;
	}
	
	
	
	@Override
	public String toString() {
		return "Product [prodId=" + prodId + ", prodName=" + prodName + ", prodMsrp=" + prodMsrp
				+ ", prodQuantityInStock=" + prodQuantityInStock + ", vendor=" + vendor + "]";
	}
	
}

