package com.sportyshoes.model;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
@Table(name="orders")
public class Order {

	@Column(name="ORDER_ID")
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer orderId;
	
	@Column(name="PROD_ID")
	private Integer prodId;
	
	@Column(name="USER_ID")
	private Integer userId;
	
	 @JsonFormat(pattern = "dd/MM/yyyy")
	@Column(name="ORDER_DATE")
	private LocalDate orderDate;
	
	@Column(name="STATUS")
	private String status;
	

	public Order() {
		super();
	}
	
	
	
	public Order(Integer orderId, LocalDate orderDate, String status) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
		this.status = status;
	}


	public Order(Integer prodId, Integer userId, LocalDate orderDate, String status) {
		super();
		this.prodId = prodId;
		this.userId = userId;
		this.orderDate = orderDate;
		this.status = status;
	}
	public Integer getOrderId() {
		return orderId;
	}
	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}
	public Integer getProdId() {
		return prodId;
	}
	public void setProdId(Integer prodId) {
		this.prodId = prodId;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public LocalDate getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", prodId=" + prodId + ", userId=" + userId + ", orderDate=" + orderDate
				+ ", status=" + status + "]";
	}
	
}
