package com.sportyshoes.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.springframework.lang.NonNull;

@Entity
@Table(name = "admin")
public class Admin {

	@Column(name="ADMIN_ID")
	@Id
	@Pattern(regexp=".+@.+\\..+",message="Please provide a valid email")
	private String adminId;
	
	
	@Column(name="PASSWORD")
	
	private String password;

	public Admin() {
		super();
	}

	public Admin(String adminId, String password) {
		super();
		this.adminId = adminId;
		this.password = password;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Admin [adminId=" + adminId + ", password=" + password + "]";
	}

}
